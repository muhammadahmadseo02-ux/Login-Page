using System;
using System.Data.SQLite;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace ModernLoginApp
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }

    public class RoundedPanel : Panel
    {
        public int BorderRadius { get; set; } = 20;
        public Color ShadowColor { get; set; } = Color.FromArgb(40, 0, 0, 0);
        public int ShadowSize { get; set; } = 10;

        public RoundedPanel()
        {
            this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            this.BackColor = Color.White;
            this.Padding = new Padding(ShadowSize + 5);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            for (int i = 0; i < ShadowSize; i++)
            {
                using (var path = GetRoundedRect(new Rectangle(i, i, Width - 1 - i * 2, Height - 1 - i * 2), BorderRadius))
                using (var brush = new SolidBrush(Color.FromArgb((int)(ShadowColor.A * (1 - (double)i / ShadowSize)), ShadowColor)))
                {
                    e.Graphics.FillPath(brush, path);
                }
            }
            var rect = new Rectangle(ShadowSize, ShadowSize, Width - 1 - ShadowSize * 2, Height - 1 - ShadowSize * 2);
            using (var path = GetRoundedRect(rect, BorderRadius))
            using (var brush = new SolidBrush(BackColor))
            {
                e.Graphics.FillPath(brush, path);
            }
        }

        private GraphicsPath GetRoundedRect(Rectangle rect, int radius)
        {
            int d = radius * 2;
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    public class ModernTextBox : Control
    {
        private TextBox innerTextBox;
        private bool isFocused = false;
        private Color borderColor = Color.FromArgb(220, 220, 220);
        private Color focusColor = Color.FromArgb(100, 149, 237);
        private int borderRadius = 8;

        public char PasswordChar
        {
            get => innerTextBox.PasswordChar;
            set => innerTextBox.PasswordChar = value;
        }

        public override string Text
        {
            get
            {
                string tag = innerTextBox.Tag?.ToString() ?? "";
                if (innerTextBox.Text == tag) return "";
                return innerTextBox.Text;
            }
            set
            {
                string tag = innerTextBox.Tag?.ToString() ?? "";
                if (string.IsNullOrEmpty(value))
                {
                    innerTextBox.Text = tag;
                    innerTextBox.ForeColor = Color.FromArgb(150, 150, 150);
                }
                else
                {
                    innerTextBox.Text = value;
                    innerTextBox.ForeColor = Color.FromArgb(50, 50, 50);
                }
            }
        }

        public string PlaceholderText
        {
            get => innerTextBox.Tag?.ToString() ?? "";
            set
            {
                innerTextBox.Tag = value;
                if (string.IsNullOrEmpty(innerTextBox.Text))
                {
                    innerTextBox.Text = value;
                    innerTextBox.ForeColor = Color.FromArgb(150, 150, 150);
                }
            }
        }

        public ModernTextBox()
        {
            this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            this.Size = new Size(250, 40);
            innerTextBox = new TextBox
            {
                BorderStyle = BorderStyle.None,
                BackColor = Color.White,
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(150, 150, 150),
                Location = new Point(12, 10),
                Width = this.Width - 24
            };
            innerTextBox.GotFocus += (s, e) =>
            {
                isFocused = true;
                string tag = innerTextBox.Tag?.ToString() ?? "";
                if (innerTextBox.Text == tag)
                {
                    innerTextBox.Text = "";
                    innerTextBox.ForeColor = Color.FromArgb(50, 50, 50);
                }
                this.Invalidate();
            };
            innerTextBox.LostFocus += (s, e) =>
            {
                isFocused = false;
                if (string.IsNullOrWhiteSpace(innerTextBox.Text))
                {
                    innerTextBox.Text = innerTextBox.Tag?.ToString() ?? "";
                    innerTextBox.ForeColor = Color.FromArgb(150, 150, 150);
                }
                this.Invalidate();
            };
            this.Controls.Add(innerTextBox);
            this.BackColor = Color.White;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            innerTextBox.Width = this.Width - 24;
            innerTextBox.Location = new Point(12, (this.Height - innerTextBox.Height) / 2);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using (var path = GetRoundedRect(rect, borderRadius))
            using (var brush = new SolidBrush(Color.White))
            {
                e.Graphics.FillPath(brush, path);
            }
            Color currentBorder = isFocused ? focusColor : borderColor;
            using (var path = GetRoundedRect(rect, borderRadius))
            using (var pen = new Pen(currentBorder, isFocused ? 2 : 1))
            {
                e.Graphics.DrawPath(pen, path);
            }
            if (isFocused)
            {
                using (var path = GetRoundedRect(new Rectangle(1, 1, Width - 3, Height - 3), borderRadius))
                using (var pen = new Pen(Color.FromArgb(60, focusColor.R, focusColor.G, focusColor.B), 1))
                {
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private GraphicsPath GetRoundedRect(Rectangle rect, int radius)
        {
            int d = radius * 2;
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    public class ModernButton : Button
    {
        private int borderRadius = 10;
        private Color hoverColor;
        private Color normalColor;
        private bool isHovered = false;

        public ModernButton()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            this.ForeColor = Color.White;
            this.normalColor = Color.FromArgb(100, 149, 237);
            this.hoverColor = Color.FromArgb(72, 118, 205);
            this.BackColor = normalColor;
            this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            isHovered = true;
            this.Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            isHovered = false;
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Color drawColor = isHovered ? hoverColor : normalColor;
            var rect = new Rectangle(0, 0, Width - 1, Height - 1);
            using (var path = GetRoundedRect(rect, borderRadius))
            using (var brush = new SolidBrush(drawColor))
            {
                e.Graphics.FillPath(brush, path);
            }
            using (var brush = new SolidBrush(ForeColor))
            {
                var size = e.Graphics.MeasureString(Text, Font);
                var point = new PointF((Width - size.Width) / 2, (Height - size.Height) / 2);
                e.Graphics.DrawString(Text, Font, brush, point);
            }
        }

        private GraphicsPath GetRoundedRect(Rectangle rect, int radius)
        {
            int d = radius * 2;
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, d, d, 180, 90);
            path.AddArc(rect.Right - d, rect.Y, d, d, 270, 90);
            path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
            path.AddArc(rect.X, rect.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }
    }

    public class LoginForm : Form
    {
        private string dbPath = Path.Combine(Application.StartupPath, "users.db");
        private string connectionString;
        private string rememberMePath = Path.Combine(Application.StartupPath, "remember.me");

        private RoundedPanel cardPanel;
        private Label lblTitle;
        private Label lblSubtitle;
        private ModernTextBox txtUsername;
        private ModernTextBox txtPassword;
        private CheckBox chkRememberMe;
        private ModernButton btnLogin;
        private Label lblOr;
        private ModernButton btnRegister;
        private Label lblMessage;
        private Label lblTogglePassword;

        private Timer fadeInTimer;
        private Timer slideTimer;
        private float opacity = 0;
        private int cardTargetY;
        private int cardCurrentY;
        private bool isRegisterMode = false;

        public LoginForm()
        {
            this.Text = "Modern Login System";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.Opacity = 0;

            InitializeDatabase();
            InitializeUI();
            InitializeAnimations();
            LoadRememberMe();
        }

        private void InitializeDatabase()
        {
            connectionString = $"Data Source={dbPath};Version=3;";
            if (!File.Exists(dbPath))
            {
                SQLiteConnection.CreateFile(dbPath);
            }
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = @"CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT UNIQUE NOT NULL,
                    Password TEXT NOT NULL
                );";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void InitializeUI()
        {
            var bgPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(245, 247, 250)
            };
            bgPanel.Paint += BgPanel_Paint;
            this.Controls.Add(bgPanel);

            cardPanel = new RoundedPanel
            {
                Size = new Size(420, 520),
                BackColor = Color.White,
                ShadowColor = Color.FromArgb(50, 0, 0, 0),
                ShadowSize = 15,
                BorderRadius = 25
            };
            cardTargetY = (this.ClientSize.Height - cardPanel.Height) / 2;
            cardCurrentY = this.ClientSize.Height + 50;
            cardPanel.Location = new Point((this.ClientSize.Width - cardPanel.Width) / 2, cardCurrentY);
            bgPanel.Controls.Add(cardPanel);

            lblTitle = new Label
            {
                Text = "Welcome Back",
                Font = new Font("Segoe UI", 26F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 60),
                AutoSize = true,
                Location = new Point(0, 40)
            };
            cardPanel.Controls.Add(lblTitle);
            CenterControl(lblTitle);

            lblSubtitle = new Label
            {
                Text = "Please sign in to continue",
                Font = new Font("Segoe UI", 11F),
                ForeColor = Color.FromArgb(150, 150, 160),
                AutoSize = true,
                Location = new Point(0, 85)
            };
            cardPanel.Controls.Add(lblSubtitle);
            CenterControl(lblSubtitle);

            txtUsername = new ModernTextBox
            {
                Size = new Size(320, 45),
                Location = new Point(50, 140),
                PlaceholderText = "Username"
            };
            cardPanel.Controls.Add(txtUsername);

            txtPassword = new ModernTextBox
            {
                Size = new Size(320, 45),
                Location = new Point(50, 205),
                PlaceholderText = "Password",
                PasswordChar = '\u25CF'
            };
            cardPanel.Controls.Add(txtPassword);

            lblTogglePassword = new Label
            {
                Text = "\U0001F441",
                AutoSize = true,
                Location = new Point(375, 215),
                Font = new Font("Segoe UI", 12F),
                Cursor = Cursors.Hand,
                ForeColor = Color.FromArgb(150, 150, 150)
            };
            lblTogglePassword.Click += LblTogglePassword_Click;
            cardPanel.Controls.Add(lblTogglePassword);

            chkRememberMe = new CheckBox
            {
                Text = "Remember Me",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(120, 120, 130),
                AutoSize = true,
                Location = new Point(50, 265),
                Cursor = Cursors.Hand
            };
            cardPanel.Controls.Add(chkRememberMe);

            btnLogin = new ModernButton
            {
                Text = "Sign In",
                Size = new Size(320, 50),
                Location = new Point(50, 310)
            };
            btnLogin.Click += BtnLogin_Click;
            cardPanel.Controls.Add(btnLogin);

            lblOr = new Label
            {
                Text = "\u2014 or \u2014",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(180, 180, 190),
                AutoSize = true,
                Location = new Point(0, 375)
            };
            cardPanel.Controls.Add(lblOr);
            CenterControl(lblOr);

            btnRegister = new ModernButton
            {
                Text = "Create Account",
                Size = new Size(320, 50),
                Location = new Point(50, 415),
                normalColor = Color.FromArgb(80, 200, 120),
                hoverColor = Color.FromArgb(60, 170, 100)
            };
            btnRegister.Click += BtnRegister_Click;
            cardPanel.Controls.Add(btnRegister);

            lblMessage = new Label
            {
                Text = "",
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(220, 80, 80),
                AutoSize = false,
                Size = new Size(320, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(50, 475)
            };
            cardPanel.Controls.Add(lblMessage);

            this.Resize += (s, e) =>
            {
                cardPanel.Location = new Point((this.ClientSize.Width - cardPanel.Width) / 2, cardPanel.Location.Y);
            };
        }

        private void BgPanel_Paint(object sender, PaintEventArgs e)
        {
            using (var brush = new LinearGradientBrush(
                this.ClientRectangle,
                Color.FromArgb(245, 247, 250),
                Color.FromArgb(230, 235, 245),
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
            using (var brush = new SolidBrush(Color.FromArgb(15, 100, 149, 237)))
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillEllipse(brush, -50, -50, 200, 200);
                e.Graphics.FillEllipse(brush, this.ClientSize.Width - 150, this.ClientSize.Height - 150, 200, 200);
            }
        }

        private void CenterControl(Control ctrl)
        {
            ctrl.Location = new Point((cardPanel.Width - ctrl.Width) / 2, ctrl.Location.Y);
        }

        private void InitializeAnimations()
        {
            fadeInTimer = new Timer { Interval = 16 };
            fadeInTimer.Tick += (s, e) =>
            {
                opacity += 0.05f;
                if (opacity >= 1)
                {
                    opacity = 1;
                    fadeInTimer.Stop();
                }
                this.Opacity = opacity;
            };
            fadeInTimer.Start();

            slideTimer = new Timer { Interval = 16 };
            slideTimer.Tick += (s, e) =>
            {
                int diff = cardTargetY - cardCurrentY;
                if (Math.Abs(diff) < 2)
                {
                    cardCurrentY = cardTargetY;
                    slideTimer.Stop();
                }
                else
                {
                    cardCurrentY += diff / 8;
                }
                cardPanel.Location = new Point((this.ClientSize.Width - cardPanel.Width) / 2, cardCurrentY);
            };
            slideTimer.Start();
        }

        private void LblTogglePassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.PasswordChar == '\0')
            {
                txtPassword.PasswordChar = '\u25CF';
                lblTogglePassword.ForeColor = Color.FromArgb(150, 150, 150);
            }
            else
            {
                txtPassword.PasswordChar = '\0';
                lblTogglePassword.ForeColor = Color.FromArgb(100, 149, 237);
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (isRegisterMode)
                DoRegister();
            else
                AuthenticateLogin();
        }

        private void AuthenticateLogin()
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                ShowMessage("Please enter your username.", false);
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Please enter your password.", false);
                return;
            }

            string hashedPassword = HashPassword(password);
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT COUNT(*) FROM Users WHERE Username = @user AND Password = @pass";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@user", username);
                    cmd.Parameters.AddWithValue("@pass", hashedPassword);
                    long count = (long)cmd.ExecuteScalar();
                    if (count > 0)
                    {
                        if (chkRememberMe.Checked)
                            File.WriteAllText(rememberMePath, username);
                        else if (File.Exists(rememberMePath))
                            File.Delete(rememberMePath);

                        ShowMessage("Welcome back, " + username + "!", true);
                    }
                    else
                    {
                        ShowMessage("Invalid username or password.", false);
                    }
                }
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (!isRegisterMode)
            {
                isRegisterMode = true;
                lblTitle.Text = "Create Account";
                lblSubtitle.Text = "Sign up to get started";
                btnLogin.Text = "Register";
                btnRegister.Text = "Back to Sign In";
                lblOr.Text = "\u2014 already have an account? \u2014";
                ClearInputs();
                ShowMessage("", false);
                return;
            }
            isRegisterMode = false;
            lblTitle.Text = "Welcome Back";
            lblSubtitle.Text = "Please sign in to continue";
            btnLogin.Text = "Sign In";
            btnRegister.Text = "Create Account";
            lblOr.Text = "\u2014 or \u2014";
            ClearInputs();
            ShowMessage("", false);
        }

        private void DoRegister()
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                ShowMessage("Please enter a username.", false);
                return;
            }
            if (username.Length < 3)
            {
                ShowMessage("Username must be at least 3 characters.", false);
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                ShowMessage("Please enter a password.", false);
                return;
            }
            if (password.Length < 4)
            {
                ShowMessage("Password must be at least 4 characters.", false);
                return;
            }

            string hashedPassword = HashPassword(password);
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string checkSql = "SELECT COUNT(*) FROM Users WHERE Username = @user";
                using (var cmd = new SQLiteCommand(checkSql, conn))
                {
                    cmd.Parameters.AddWithValue("@user", username);
                    long count = (long)cmd.ExecuteScalar();
                    if (count > 0)
                    {
                        ShowMessage("Username already exists.", false);
                        return;
                    }
                }
                string insertSql = "INSERT INTO Users (Username, Password) VALUES (@user, @pass)";
                using (var cmd = new SQLiteCommand(insertSql, conn))
                {
                    cmd.Parameters.AddWithValue("@user", username);
                    cmd.Parameters.AddWithValue("@pass", hashedPassword);
                    cmd.ExecuteNonQuery();
                }
            }

            ShowMessage("Account created successfully!", true);
            ClearInputs();

            var switchTimer = new Timer { Interval = 1500 };
            switchTimer.Tick += (s, e) =>
            {
                switchTimer.Stop();
                BtnRegister_Click(null, null);
            };
            switchTimer.Start();
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void ShowMessage(string msg, bool isSuccess)
        {
            lblMessage.Text = msg;
            lblMessage.ForeColor = isSuccess ? Color.FromArgb(60, 170, 100) : Color.FromArgb(220, 80, 80);
            var pulseTimer = new Timer { Interval = 30 };
            int steps = 0;
            pulseTimer.Tick += (s, e) =>
            {
                steps++;
                if (steps > 10)
                {
                    pulseTimer.Stop();
                    lblMessage.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
                }
                else
                {
                    float size = 10 + (float)Math.Sin(steps * 0.3) * 1.5f;
                    lblMessage.Font = new Font("Segoe UI", size, FontStyle.Bold);
                }
            };
            pulseTimer.Start();
        }

        private void ClearInputs()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
        }

        private void LoadRememberMe()
        {
            if (File.Exists(rememberMePath))
            {
                string savedUser = File.ReadAllText(rememberMePath).Trim();
                if (!string.IsNullOrEmpty(savedUser))
                {
                    txtUsername.Text = savedUser;
                    chkRememberMe.Checked = true;
                }
            }
        }
    }
}
